
	/* Unity player! */
	<!--
	var unityObjectUrl = "http://webplayer.unity3d.com/download_webplayer-3.x/3.0/uo/UnityObject2.js";
	if (document.location.protocol == 'https:')
		unityObjectUrl = unityObjectUrl.replace("http://", "https://ssl-");
	document.write('<script type="text/javascript" src="' + unityObjectUrl + '"></script>');
	-->

	/* Unity instance loading! Add id of element and link to .unity3d file! */
	var u = new UnityObject2();
		$(function(){
			u.initPlugin(jQuery("#ExampleNameHere")[0], "http://www.frictionpointstudios.com/storage/embed-code-for-blog/LoadOnDemandExample.unity3d");
		});	



		$(document).ready(function(){
			$(".nav-button").click(function () {
			$(".nav-button,.primary-nav").toggleClass("open");
			});    
		});



		$(document).ready(function(){
		  $(".unityjshack").click(function(){
		    $(".unityhide").toggle();
		  });
		});
